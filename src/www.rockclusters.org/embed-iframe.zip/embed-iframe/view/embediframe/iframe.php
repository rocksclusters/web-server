<div class="iframe-wrapper">
  <iframe src="<?php echo $url ?>" frameborder="0" style="height:<?=$height?>px;width:<?=$width?>px;">Please upgrade your browser</iframe>
</div>